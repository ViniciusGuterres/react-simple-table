--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE react_table_project;
--
-- Name: react_table_project; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE react_table_project WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE react_table_project OWNER TO postgres;

\connect react_table_project

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: users_data; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA users_data;


ALTER SCHEMA users_data OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.access (
    access_id integer NOT NULL,
    business_technology character(50) NOT NULL,
    ip_address character(50) NOT NULL,
    mac_address character(50) NOT NULL,
    user_agent character(250) NOT NULL,
    login character(50) NOT NULL
);


ALTER TABLE users_data.access OWNER TO postgres;

--
-- Name: access_access_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.access_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.access_access_id_seq OWNER TO postgres;

--
-- Name: access_access_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.access_access_id_seq OWNED BY users_data.access.access_id;


--
-- Name: address; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.address (
    address_id integer NOT NULL,
    street_address character(50) NOT NULL,
    street_name character(50) NOT NULL,
    street_sufix character(50) NOT NULL,
    city character(50) NOT NULL,
    city_prefix character(50) NOT NULL,
    secondary_address character(50) NOT NULL,
    direction character(50) NOT NULL,
    state character(50) NOT NULL,
    country character(50) NOT NULL
);


ALTER TABLE users_data.address OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.address_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.address_address_id_seq OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.address_address_id_seq OWNED BY users_data.address.address_id;


--
-- Name: cars; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.cars (
    car_id integer NOT NULL,
    name character(50) NOT NULL,
    fuel character(50),
    manufacturer character(50) NOT NULL,
    model character(50) NOT NULL,
    type character(50) NOT NULL
);


ALTER TABLE users_data.cars OWNER TO postgres;

--
-- Name: cars_car_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.cars_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.cars_car_id_seq OWNER TO postgres;

--
-- Name: cars_car_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.cars_car_id_seq OWNED BY users_data.cars.car_id;


--
-- Name: job; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.job (
    job_id integer NOT NULL,
    title character(50) NOT NULL,
    address character(50) NOT NULL,
    salary real NOT NULL,
    salary_current_symbol character(10) NOT NULL
);


ALTER TABLE users_data.job OWNER TO postgres;

--
-- Name: job_job_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.job_job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.job_job_id_seq OWNER TO postgres;

--
-- Name: job_job_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.job_job_id_seq OWNED BY users_data.job.job_id;


--
-- Name: products; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.products (
    product_id integer NOT NULL,
    business_technology character(50) NOT NULL,
    business_industry character(50) NOT NULL,
    commerce_department character(50) NOT NULL,
    company_name character(50) NOT NULL,
    name character(50) NOT NULL,
    description character(250) NOT NULL,
    material character(50) NOT NULL,
    price real NOT NULL,
    appliance character(50)
);


ALTER TABLE users_data.products OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.product_product_id_seq OWNED BY users_data.products.product_id;


--
-- Name: users; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users (
    user_id integer NOT NULL,
    first_name character(50) NOT NULL,
    gender character(50),
    birth_date timestamp without time zone NOT NULL
);


ALTER TABLE users_data.users OWNER TO postgres;

--
-- Name: users_accesses; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users_accesses (
    user_id integer NOT NULL,
    access_id integer NOT NULL
);


ALTER TABLE users_data.users_accesses OWNER TO postgres;

--
-- Name: users_addresses; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users_addresses (
    user_id integer NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE users_data.users_addresses OWNER TO postgres;

--
-- Name: users_cars; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users_cars (
    user_id integer NOT NULL,
    car_id integer NOT NULL
);


ALTER TABLE users_data.users_cars OWNER TO postgres;

--
-- Name: users_jobs; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users_jobs (
    user_id integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE users_data.users_jobs OWNER TO postgres;

--
-- Name: users_products; Type: TABLE; Schema: users_data; Owner: postgres
--

CREATE TABLE users_data.users_products (
    user_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE users_data.users_products OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: users_data; Owner: postgres
--

CREATE SEQUENCE users_data.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_data.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: users_data; Owner: postgres
--

ALTER SEQUENCE users_data.users_user_id_seq OWNED BY users_data.users.user_id;


--
-- Name: access access_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.access ALTER COLUMN access_id SET DEFAULT nextval('users_data.access_access_id_seq'::regclass);


--
-- Name: address address_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.address ALTER COLUMN address_id SET DEFAULT nextval('users_data.address_address_id_seq'::regclass);


--
-- Name: cars car_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.cars ALTER COLUMN car_id SET DEFAULT nextval('users_data.cars_car_id_seq'::regclass);


--
-- Name: job job_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.job ALTER COLUMN job_id SET DEFAULT nextval('users_data.job_job_id_seq'::regclass);


--
-- Name: products product_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.products ALTER COLUMN product_id SET DEFAULT nextval('users_data.product_product_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users ALTER COLUMN user_id SET DEFAULT nextval('users_data.users_user_id_seq'::regclass);


--
-- Data for Name: access; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.access (access_id, business_technology, ip_address, mac_address, user_agent, login) FROM stdin;
\.
COPY users_data.access (access_id, business_technology, ip_address, mac_address, user_agent, login) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: address; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.address (address_id, street_address, street_name, street_sufix, city, city_prefix, secondary_address, direction, state, country) FROM stdin;
\.
COPY users_data.address (address_id, street_address, street_name, street_sufix, city, city_prefix, secondary_address, direction, state, country) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: cars; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.cars (car_id, name, fuel, manufacturer, model, type) FROM stdin;
\.
COPY users_data.cars (car_id, name, fuel, manufacturer, model, type) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: job; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.job (job_id, title, address, salary, salary_current_symbol) FROM stdin;
\.
COPY users_data.job (job_id, title, address, salary, salary_current_symbol) FROM '$$PATH$$/3069.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.products (product_id, business_technology, business_industry, commerce_department, company_name, name, description, material, price, appliance) FROM stdin;
\.
COPY users_data.products (product_id, business_technology, business_industry, commerce_department, company_name, name, description, material, price, appliance) FROM '$$PATH$$/3071.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users (user_id, first_name, gender, birth_date) FROM stdin;
\.
COPY users_data.users (user_id, first_name, gender, birth_date) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: users_accesses; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users_accesses (user_id, access_id) FROM stdin;
\.
COPY users_data.users_accesses (user_id, access_id) FROM '$$PATH$$/3076.dat';

--
-- Data for Name: users_addresses; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users_addresses (user_id, address_id) FROM stdin;
\.
COPY users_data.users_addresses (user_id, address_id) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: users_cars; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users_cars (user_id, car_id) FROM stdin;
\.
COPY users_data.users_cars (user_id, car_id) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: users_jobs; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users_jobs (user_id, job_id) FROM stdin;
\.
COPY users_data.users_jobs (user_id, job_id) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: users_products; Type: TABLE DATA; Schema: users_data; Owner: postgres
--

COPY users_data.users_products (user_id, product_id) FROM stdin;
\.
COPY users_data.users_products (user_id, product_id) FROM '$$PATH$$/3073.dat';

--
-- Name: access_access_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.access_access_id_seq', 100, true);


--
-- Name: address_address_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.address_address_id_seq', 100, true);


--
-- Name: cars_car_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.cars_car_id_seq', 100, true);


--
-- Name: job_job_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.job_job_id_seq', 100, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.product_product_id_seq', 300, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: users_data; Owner: postgres
--

SELECT pg_catalog.setval('users_data.users_user_id_seq', 100, true);


--
-- Name: access access_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (access_id);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (address_id);


--
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (car_id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (job_id);


--
-- Name: products product_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.products
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_accesses users_accesses_access_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_accesses
    ADD CONSTRAINT users_accesses_access_id_fkey FOREIGN KEY (access_id) REFERENCES users_data.access(access_id);


--
-- Name: users_accesses users_accesses_user_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_accesses
    ADD CONSTRAINT users_accesses_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_data.users(user_id);


--
-- Name: users_addresses users_addresses_address_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_addresses
    ADD CONSTRAINT users_addresses_address_id_fkey FOREIGN KEY (address_id) REFERENCES users_data.address(address_id);


--
-- Name: users_addresses users_addresses_user_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_addresses
    ADD CONSTRAINT users_addresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_data.users(user_id);


--
-- Name: users_cars users_cars_car_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_cars
    ADD CONSTRAINT users_cars_car_id_fkey FOREIGN KEY (car_id) REFERENCES users_data.cars(car_id);


--
-- Name: users_cars users_cars_user_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_cars
    ADD CONSTRAINT users_cars_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_data.users(user_id);


--
-- Name: users_jobs users_jobs_job_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_jobs
    ADD CONSTRAINT users_jobs_job_id_fkey FOREIGN KEY (job_id) REFERENCES users_data.job(job_id);


--
-- Name: users_jobs users_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_jobs
    ADD CONSTRAINT users_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_data.users(user_id);


--
-- Name: users_products users_products_product_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_products
    ADD CONSTRAINT users_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES users_data.products(product_id);


--
-- Name: users_products users_products_user_id_fkey; Type: FK CONSTRAINT; Schema: users_data; Owner: postgres
--

ALTER TABLE ONLY users_data.users_products
    ADD CONSTRAINT users_products_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_data.users(user_id);


--
-- PostgreSQL database dump complete
--

